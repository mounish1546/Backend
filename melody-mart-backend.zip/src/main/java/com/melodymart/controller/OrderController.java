package com.melodymart.controller;

import com.melodymart.model.Order;
import com.melodymart.service.OrderService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/orders")
@CrossOrigin(origins="*")
public class OrderController {
    private final OrderService service;
    public OrderController(OrderService service) { this.service=service; }

    @PostMapping("/{userId}") public Order place(@PathVariable Long userId,@RequestBody Order order) { return service.place(userId,order); }
    @GetMapping("/{userId}") public List<Order> history(@PathVariable Long userId) { return service.history(userId); }
}
