package com.melodymart.service;

import com.melodymart.model.*;
import com.melodymart.repository.*;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.util.*;

@Service
public class CartService {
    private final CartItemRepository cartRepo;
    private final UserRepository userRepo;
    private final ProductRepository productRepo;

    public CartService(CartItemRepository c, UserRepository u, ProductRepository p) {
        cartRepo=c; userRepo=u; productRepo=p;
    }

    public List<CartItem> get(Long userId) { return cartRepo.findByUserId(userId); }

    public CartItem add(Long userId, Long productId, int quantity) {
        User u=userRepo.findById(userId).orElseThrow();
        Product p=productRepo.findById(productId).orElseThrow();
        CartItem item=cartRepo.findByUserIdAndProductId(userId,productId)
                .orElse(CartItem.builder().user(u).product(p).quantity(0).build());
        item.setQuantity(item.getQuantity()+quantity);
        if(item.getQuantity()<1) item.setQuantity(1);
        return cartRepo.save(item);
    }

    public void remove(Long userId, Long productId) {
        cartRepo.findByUserIdAndProductId(userId,productId).ifPresent(cartRepo::delete);
    }

    public BigDecimal total(Long userId) {
        return get(userId).stream()
                .map(i -> i.getProduct().getPrice().multiply(BigDecimal.valueOf(i.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);
    }

    public void clear(Long userId) { cartRepo.deleteByUserId(userId); }
}
