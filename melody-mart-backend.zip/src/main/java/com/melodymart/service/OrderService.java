package com.melodymart.service;

import com.melodymart.model.*;
import com.melodymart.repository.*;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.*;

@Service
public class OrderService {
    private final OrderRepository orderRepo;
    private final CartService cartService;
    private final UserRepository userRepo;

    public OrderService(OrderRepository o, CartService c, UserRepository u) {
        orderRepo=o; cartService=c; userRepo=u;
    }

    public Order place(Long userId, Order request) {
        User user=userRepo.findById(userId).orElseThrow();
        List<CartItem> cart=cartService.get(userId);
        if(cart.isEmpty()) throw new RuntimeException("Cart is empty");

        Order order=Order.builder()
                .user(user).address(request.getAddress()).city(request.getCity())
                .pinCode(request.getPinCode()).paymentMethod(request.getPaymentMethod())
                .status("CONFIRMED").createdAt(LocalDateTime.now())
                .total(BigDecimal.ZERO).build();

        BigDecimal total=BigDecimal.ZERO;
        for(CartItem c:cart) {
            BigDecimal line=c.getProduct().getPrice().multiply(BigDecimal.valueOf(c.getQuantity()));
            OrderItem item=OrderItem.builder().order(order).product(c.getProduct())
                    .quantity(c.getQuantity()).price(c.getProduct().getPrice()).build();
            order.getItems().add(item);
            total=total.add(line);
        }
        order.setTotal(total);
        Order saved=orderRepo.save(order);
        cartService.clear(userId);
        return saved;
    }

    public List<Order> history(Long userId) { return orderRepo.findByUserIdOrderByCreatedAtDesc(userId); }
}
