package com.melodymart.controller;

import com.melodymart.model.CartItem;
import com.melodymart.service.CartService;
import org.springframework.web.bind.annotation.*;
import java.math.BigDecimal;
import java.util.*;

@RestController
@RequestMapping("/api/cart")
@CrossOrigin(origins="*")
public class CartController {
    private final CartService service;
    public CartController(CartService service) { this.service=service; }

    @GetMapping("/{userId}") public List<CartItem> get(@PathVariable Long userId) { return service.get(userId); }

    @PostMapping("/{userId}/add")
    public CartItem add(@PathVariable Long userId,@RequestBody Map<String,Object> body) {
        Long productId=Long.valueOf(body.get("productId").toString());
        int quantity=body.get("quantity")==null?1:Integer.parseInt(body.get("quantity").toString());
        return service.add(userId,productId,quantity);
    }

    @DeleteMapping("/{userId}/product/{productId}")
    public void remove(@PathVariable Long userId,@PathVariable Long productId) { service.remove(userId,productId); }

    @GetMapping("/{userId}/total") public Map<String,BigDecimal> total(@PathVariable Long userId) {
        return Map.of("total",service.total(userId));
    }
}
