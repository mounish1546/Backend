package com.melodymart.service;

import com.melodymart.model.Product;
import com.melodymart.repository.ProductRepository;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ProductService {
    private final ProductRepository repo;
    public ProductService(ProductRepository repo) { this.repo = repo; }

    public List<Product> all() { return repo.findAll(); }
    public Product get(Long id) { return repo.findById(id).orElseThrow(() -> new RuntimeException("Product not found")); }
    public List<Product> category(String c) { return repo.findByCategoryIgnoreCase(c); }
    public List<Product> search(String q) { return repo.findByNameContainingIgnoreCase(q); }
    public Product save(Product p) { return repo.save(p); }
    public void delete(Long id) { repo.deleteById(id); }
}
