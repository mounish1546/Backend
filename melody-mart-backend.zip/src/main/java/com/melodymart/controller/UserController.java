package com.melodymart.controller;

import com.melodymart.model.User;
import com.melodymart.service.UserService;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
@CrossOrigin(origins="*")
public class UserController {
    private final UserService service;
    public UserController(UserService service) { this.service=service; }

    @PostMapping("/register")
    public ResponseEntity<User> register(@RequestBody User user) {
        User saved=service.register(user); saved.setPassword(null);
        return ResponseEntity.status(HttpStatus.CREATED).body(saved);
    }

    @PostMapping("/login")
    public User login(@RequestBody Map<String,String> body) {
        return service.login(body.get("email"), body.get("password"));
    }

    @GetMapping("/{id}")
    public User get(@PathVariable Long id) { User u=service.get(id); u.setPassword(null); return u; }

    @PutMapping("/{id}")
    public User update(@PathVariable Long id,@RequestBody User user) {
        User u=service.update(id,user); u.setPassword(null); return u;
    }
}
