package com.melodymart.controller;

import com.melodymart.model.Product;
import com.melodymart.service.ProductService;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/products")
@CrossOrigin(origins="*")
public class ProductController {
    private final ProductService service;
    public ProductController(ProductService service) { this.service=service; }

    @GetMapping public List<Product> all() { return service.all(); }
    @GetMapping("/{id}") public Product get(@PathVariable Long id) { return service.get(id); }
    @GetMapping("/category/{category}") public List<Product> category(@PathVariable String category) { return service.category(category); }
    @GetMapping("/search") public List<Product> search(@RequestParam String q) { return service.search(q); }
    @PostMapping public Product create(@RequestBody Product p) { return service.save(p); }
    @PutMapping("/{id}") public Product update(@PathVariable Long id,@RequestBody Product p) { p.setId(id); return service.save(p); }
    @DeleteMapping("/{id}") public void delete(@PathVariable Long id) { service.delete(id); }
}
