package com.melodymart.config;

import com.melodymart.model.Product;
import com.melodymart.repository.ProductRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import java.math.BigDecimal;
import java.util.List;

@Configuration
public class DataSeeder {
    @Bean
    CommandLineRunner seedProducts(ProductRepository repo) {
        return args -> {
            if (repo.count() == 0) {
                repo.saveAll(List.of(
                    Product.builder().name("Classic Acoustic Guitar").category("Guitars").price(new BigDecimal("8999")).description("Warm tone, spruce top").stock(20).build(),
                    Product.builder().name("Studio Electric Guitar").category("Guitars").price(new BigDecimal("14999")).description("Smooth pickups, bold tone").stock(15).build(),
                    Product.builder().name("Digital Keyboard 61").category("Keyboards").price(new BigDecimal("11999")).description("61 keys with 300 sounds").stock(12).build(),
                    Product.builder().name("Stage Piano 88").category("Keyboards").price(new BigDecimal("24999")).description("Weighted keys, rich sound").stock(8).build(),
                    Product.builder().name("Acoustic Drum Kit").category("Drums").price(new BigDecimal("21999")).description("Complete 5-piece kit").stock(10).build(),
                    Product.builder().name("Concert Violin").category("Strings").price(new BigDecimal("7999")).description("Hand-finished maple body").stock(14).build()
                ));
            }
        };
    }
}
