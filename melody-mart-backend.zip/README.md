# Melody Mart Backend

Spring Boot REST API for the Melody Mart frontend.

## Requirements
- Java 17+
- Maven
- MySQL/Aiven MySQL

## Database
Create a database named `melody_mart`, or change DB_NAME.

Environment variables:
DB_HOST
DB_PORT
DB_NAME
DB_USERNAME
DB_PASSWORD

## Run
mvn spring-boot:run

Backend URL:
http://localhost:8080

## Main APIs
POST /api/users/register
POST /api/users/login
GET  /api/users/{id}
PUT  /api/users/{id}

GET  /api/products
GET  /api/products/{id}
GET  /api/products/category/{category}
GET  /api/products/search?q=guitar
POST /api/products
PUT  /api/products/{id}
DELETE /api/products/{id}

GET  /api/cart/{userId}
POST /api/cart/{userId}/add
DELETE /api/cart/{userId}/product/{productId}
GET /api/cart/{userId}/total

POST /api/orders/{userId}
GET /api/orders/{userId}

This is a college-project REST backend. Authentication is intentionally simple for this version; production apps should use JWT/session authentication, role-based authorization, validation, and a real payment gateway.
